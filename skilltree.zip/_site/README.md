To generate the site it needs jekyll with the relative-links plugin

https://github.com/benbalter/jekyll-relative-links

